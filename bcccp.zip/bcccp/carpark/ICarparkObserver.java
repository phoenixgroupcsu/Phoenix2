package bcccp.carpark;

public interface ICarparkObserver {
	
	public void notifyCarparkEvent();
	

}
